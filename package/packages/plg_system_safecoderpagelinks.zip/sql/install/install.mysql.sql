CREATE TABLE `#__safecoder_pagelinks` (
  `ArticleID` int(11) NOT NULL DEFAULT 0,
  `CategoryID` int(11) NOT NULL DEFAULT 0,
  `Link` text NOT NULL DEFAULT '',
  `Title` text NOT NULL DEFAULT ''
);